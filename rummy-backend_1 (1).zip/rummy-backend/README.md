# Real-Time Multiplayer Rummy — Backend

A FastAPI + WebSocket backend for multiplayer Indian Rummy: JWT auth, room-based
real-time gameplay, in-room chat, and concurrency-safe turn handling.

Tested end-to-end already (see `tests/`) — this README gets you from zero to a
**live public URL** you can share with anyone.

## What's inside

```
app/
  main.py               FastAPI app: REST auth routes + WebSocket game rooms
  auth.py               Password hashing + JWT creation/verification
  database.py           SQLAlchemy engine (SQLite locally, Postgres in prod)
  models.py             User / MatchHistory / ChatMessage tables
  schemas.py             Request/response validation
  game.py               Pure-Python Rummy rules engine (no networking)
  connection_manager.py  Tracks WebSocket connections per room + per-room lock
tests/
  test_game.py          Unit tests for the rules engine
  e2e_test.py            Two-player WebSocket simulation (auth, play, chat)
test_client/index.html   Standalone browser test client — no localhost needed
render.yaml, Procfile    Deployment config
```

## Run it locally first (optional, to poke around before deploying)

```bash
pip install -r requirements.txt --break-system-packages
uvicorn app.main:app --reload
```
Visit `http://localhost:8000/docs` for interactive API docs.

Run the rules-engine tests any time with:
```bash
python tests/test_game.py
```

## Deploy for real — Render free tier (~5 minutes)

1. Push this folder to a new GitHub repo.
2. Go to https://render.com → New → **Blueprint** → connect your repo.
   Render reads `render.yaml` automatically and provisions:
   - a free web service running `uvicorn app.main:app`
   - a free Postgres database, wired up via `DATABASE_URL`
   - a random `JWT_SECRET` (auto-generated, never hardcoded)
3. Click **Apply**. Wait for the build to finish (2–4 minutes).
4. You'll get a URL like `https://rummy-backend-xxxx.onrender.com`. That's your
   live backend — reachable by anyone, anytime, from any device.

   Note: Render's free web services "sleep" after ~15 minutes with no traffic
   and take ~30s to wake back up on the next request — expected on the free
   tier, not a bug. Upgrading the plan removes this.

## Try it — no localhost, no install

1. Open `test_client/index.html` by double-clicking it (it's just a static
   file — works from your desktop, no server needed to serve *it*).
2. Paste your Render URL into the "Backend URL" field.
3. Register two different usernames (open the file in two browser windows/tabs
   to act as two players), log both in, both connect to the same Room ID.
4. Either player clicks **Start game** once both are in the room. Draw,
   discard, and chat — you'll see both windows update live.

Since it's a static HTML file, you can also upload it anywhere (GitHub Pages,
a Google Drive shared file, email it to a friend) — anyone who opens it and
points it at your Render URL can play with you.

## API reference

| Method | Path | Purpose |
|---|---|---|
| POST | `/register` | Create account, returns JWT |
| POST | `/login` | Returns JWT |
| GET | `/rooms/{room_id}/join` | Peek at a room's current players/status |
| WS | `/ws/room/{room_id}` | Connect, then send `{"type":"auth","token":...}` first |

WebSocket message types you send: `start`, `draw_stock`, `draw_discard`,
`discard` (`{"card":"7H"}`), `declare` (`{"groups":[[...]]}`), `chat` (`{"text":"..."}`).

## Design notes (for your resume writeup / interview talking points)

- **Concurrency**: each room has its own `asyncio.Lock`; every game-state
  mutation is wrapped in it, so two players' near-simultaneous moves can't
  race and corrupt shared state. Chat bypasses the lock since it doesn't
  touch game state.
- **Auth**: JWT sent as the *first WebSocket message* rather than a header,
  since browsers can't set custom headers on the WS handshake.
- **Disconnect handling**: `WebSocketDisconnect` is caught, the player is
  removed from the room's active-connection map, and everyone else is
  notified — the game state itself is preserved so a player can reconnect.
- **Privacy**: `public_state()` sends each player only their own hand;
  opponents' hands are represented only as counts.
