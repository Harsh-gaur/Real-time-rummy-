import asyncio
import json
from fastapi import WebSocket


class ConnectionManager:
    """
    Tracks active WebSocket connections per room and provides a per-room
    asyncio.Lock so two players' near-simultaneous moves can never corrupt
    shared game state (classic real-time concurrency edge case).
    """

    def __init__(self):
        self.rooms: dict[str, dict[str, WebSocket]] = {}  # room_id -> {username: ws}
        self.locks: dict[str, asyncio.Lock] = {}

    def get_lock(self, room_id: str) -> asyncio.Lock:
        if room_id not in self.locks:
            self.locks[room_id] = asyncio.Lock()
        return self.locks[room_id]

    async def connect(self, room_id: str, username: str, websocket: WebSocket):
        self.rooms.setdefault(room_id, {})[username] = websocket

    def disconnect(self, room_id: str, username: str):
        if room_id in self.rooms and username in self.rooms[room_id]:
            del self.rooms[room_id][username]
            if not self.rooms[room_id]:
                del self.rooms[room_id]

    def usernames_in_room(self, room_id: str) -> list[str]:
        return list(self.rooms.get(room_id, {}).keys())

    async def broadcast(self, room_id: str, message: dict, exclude: str | None = None):
        for username, ws in list(self.rooms.get(room_id, {}).items()):
            if username == exclude:
                continue
            try:
                await ws.send_text(json.dumps(message))
            except Exception:
                # Connection dropped mid-broadcast; clean it up rather than crash.
                self.disconnect(room_id, username)

    async def send_personal(self, room_id: str, username: str, message: dict):
        ws = self.rooms.get(room_id, {}).get(username)
        if ws:
            await ws.send_text(json.dumps(message))

    async def broadcast_personalized_state(self, room_id: str, game, event: str | None = None):
        """Sends each player their own hand privately, plus shared public info."""
        for username, ws in list(self.rooms.get(room_id, {}).items()):
            state = game.public_state(for_player=username)
            payload = {"type": "state", "event": event, **state}
            try:
                await ws.send_text(json.dumps(payload))
            except Exception:
                self.disconnect(room_id, username)


manager = ConnectionManager()
