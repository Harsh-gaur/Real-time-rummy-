"""
Rummy game engine (13-card Indian Rummy rules, simplified).

Kept completely independent of FastAPI/WebSockets so it can be unit
tested on its own and reused by any transport layer.
"""
import random
from dataclasses import dataclass, field

SUITS = ["S", "H", "D", "C"]  # Spades, Hearts, Diamonds, Clubs
RANKS = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"]
RANK_VALUE = {rank: i for i, rank in enumerate(RANKS, start=1)}


class RummyError(Exception):
    """Raised for any invalid move so the server can send a clean error back."""


@dataclass
class Card:
    rank: str
    suit: str
    is_printed_joker: bool = False

    def __str__(self):
        return "JOKER" if self.is_printed_joker else f"{self.rank}{self.suit}"

    def __eq__(self, other):
        return str(self) == str(other)

    def __hash__(self):
        return hash(str(self))


def build_deck(num_decks: int) -> list[Card]:
    cards = []
    for _ in range(num_decks):
        for suit in SUITS:
            for rank in RANKS:
                cards.append(Card(rank, suit))
        cards.append(Card("", "", is_printed_joker=True))
        cards.append(Card("", "", is_printed_joker=True))
    random.shuffle(cards)
    return cards


class RummyGame:
    """
    One instance = one active game in one room.
    Supports 2-6 players. Uses 2 decks (+ printed jokers) if more than 2
    players are seated, matching standard Indian Rummy conventions.
    """

    def __init__(self, room_id: str, players: list[str]):
        if not (2 <= len(players) <= 6):
            raise RummyError("Rummy requires 2 to 6 players")
        self.room_id = room_id
        self.players = players
        self.hands: dict[str, list[Card]] = {p: [] for p in players}
        self.stock: list[Card] = []
        self.discard_pile: list[Card] = []
        self.wildcard_rank: str | None = None
        self.turn_index = 0
        self.phase = "draw"  # "draw" then "discard", alternating per turn
        self.status = "waiting"  # waiting -> playing -> finished
        self.winner: str | None = None

    # ---------- setup ----------

    def start(self):
        num_decks = 1 if len(self.players) <= 2 else 2
        self.stock = build_deck(num_decks)

        for player in self.players:
            self.hands[player] = [self.stock.pop() for _ in range(13)]

        # Wildcard joker rank: draw one card, its rank is wild for everyone
        wildcard_card = self.stock.pop()
        self.wildcard_rank = wildcard_card.rank if not wildcard_card.is_printed_joker else "A"
        self.stock.insert(0, wildcard_card)  # keep deck size consistent

        self.discard_pile = [self.stock.pop()]
        self.status = "playing"
        self.phase = "draw"

    @property
    def current_player(self) -> str:
        return self.players[self.turn_index]

    def _require_turn(self, player: str):
        if self.status != "playing":
            raise RummyError("Game is not active")
        if player != self.current_player:
            raise RummyError("It is not your turn")

    # ---------- moves ----------

    def draw_from_stock(self, player: str) -> Card:
        self._require_turn(player)
        if self.phase != "draw":
            raise RummyError("You must discard before drawing again")
        if not self.stock:
            self._reshuffle_discard_into_stock()
        card = self.stock.pop()
        self.hands[player].append(card)
        self.phase = "discard"
        return card

    def draw_from_discard(self, player: str) -> Card:
        self._require_turn(player)
        if self.phase != "draw":
            raise RummyError("You must discard before drawing again")
        if not self.discard_pile:
            raise RummyError("Discard pile is empty")
        card = self.discard_pile.pop()
        self.hands[player].append(card)
        self.phase = "discard"
        return card

    def discard(self, player: str, card_str: str):
        self._require_turn(player)
        if self.phase != "discard":
            raise RummyError("You must draw before discarding")
        hand = self.hands[player]
        match = next((c for c in hand if str(c) == card_str), None)
        if match is None:
            raise RummyError("You don't hold that card")
        hand.remove(match)
        self.discard_pile.append(match)
        self.phase = "draw"
        self.turn_index = (self.turn_index + 1) % len(self.players)

    def _reshuffle_discard_into_stock(self):
        if len(self.discard_pile) <= 1:
            raise RummyError("No cards left to draw")
        top = self.discard_pile.pop()
        self.stock = self.discard_pile
        random.shuffle(self.stock)
        self.discard_pile = [top]

    # ---------- declaring / winning ----------

    def declare(self, player: str, groups: list[list[str]], finish_card: str):
        """
        Call this instead of discard() on your final turn.

        groups: your 13 non-finishing cards arranged into valid melds, e.g.
        [["AS","2S","3S"], ["4H","4C","4D"], ["7S","8S","9S","10S"], ["KH","KH-joker"]]
        finish_card: the one remaining card, discarded as part of declaring
        (mirrors a normal discard, so the total is always groups + 1 card = full hand).
        """
        self._require_turn(player)
        if self.phase != "discard":
            raise RummyError("You must draw before declaring")

        hand = self.hands[player]
        hand_cards = sorted(str(c) for c in hand)
        flat = sorted(c for group in groups for c in group) + [finish_card]

        if sorted(flat) != hand_cards:
            raise RummyError("Groups plus finish card must use exactly your current hand")

        pure_sequences = 0
        for group in groups:
            group_cards = [self._parse_card_str(player, c) for c in group]
            if self._is_pure_sequence(group_cards):
                pure_sequences += 1
            elif self._is_sequence_with_joker(group_cards) or self._is_set(group_cards):
                continue
            else:
                raise RummyError(f"Invalid group: {group}")

        if pure_sequences < 1:
            raise RummyError("You need at least one pure sequence (no jokers) to declare")
        if len(groups) < 2:
            raise RummyError("You need at least two sequences to declare")

        self.status = "finished"
        self.winner = player
        return True

    def _parse_card_str(self, player: str, card_str: str) -> Card:
        for c in self.hands[player]:
            if str(c) == card_str:
                return c
        raise RummyError(f"Unknown card: {card_str}")

    def _is_wild(self, card: Card) -> bool:
        return card.is_printed_joker or card.rank == self.wildcard_rank

    def _is_set(self, cards: list[Card]) -> bool:
        if not (3 <= len(cards) <= 4):
            return False
        naturals = [c for c in cards if not self._is_wild(c)]
        if not naturals:
            return False
        rank = naturals[0].rank
        if any(c.rank != rank for c in naturals):
            return False
        suits = [c.suit for c in naturals]
        return len(suits) == len(set(suits))  # no duplicate suits among naturals

    def _is_pure_sequence(self, cards: list[Card]) -> bool:
        if any(self._is_wild(c) for c in cards) or len(cards) < 3:
            return False
        return self._is_consecutive_same_suit([RANK_VALUE[c.rank] for c in cards], [c.suit for c in cards])

    def _is_sequence_with_joker(self, cards: list[Card]) -> bool:
        if len(cards) < 3:
            return False
        wilds = [c for c in cards if self._is_wild(c)]
        naturals = [c for c in cards if not self._is_wild(c)]
        if not naturals:
            return False
        suit = naturals[0].suit
        if any(c.suit != suit for c in naturals):
            return False
        values = sorted(RANK_VALUE[c.rank] for c in naturals)
        if len(set(values)) != len(values):
            return False  # duplicate rank can't be in one sequence
        gaps_needed = (values[-1] - values[0] + 1) - len(values)
        return gaps_needed <= len(wilds) and (values[-1] - values[0] + 1) <= len(cards)

    @staticmethod
    def _is_consecutive_same_suit(values: list[int], suits: list[str]) -> bool:
        if len(set(suits)) != 1:
            return False
        values = sorted(values)
        if len(set(values)) != len(values):
            return False
        return values[-1] - values[0] == len(values) - 1

    # ---------- serialization ----------

    def public_state(self, for_player: str | None = None) -> dict:
        """State safe to broadcast: hides other players' hand contents,
        except the winner's hand is revealed to everyone once the game ends."""
        return {
            "room_id": self.room_id,
            "status": self.status,
            "players": self.players,
            "hand_sizes": {p: len(h) for p, h in self.hands.items()},
            "your_hand": [str(c) for c in self.hands[for_player]] if for_player else None,
            "winning_hand": [str(c) for c in self.hands[self.winner]] if self.winner else None,
            "discard_top": str(self.discard_pile[-1]) if self.discard_pile else None,
            "stock_count": len(self.stock),
            "current_player": self.current_player if self.status == "playing" else None,
            "phase": self.phase,
            "wildcard_rank": self.wildcard_rank,
            "winner": self.winner,
        }
