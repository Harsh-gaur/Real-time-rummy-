import json
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session

from app.database import Base, engine, get_db
from app import models, schemas, auth
from app.game import RummyGame, RummyError
from app.connection_manager import manager

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Real-Time Rummy API")

# Wide-open CORS so the static test client (opened as a local file, or
# hosted anywhere) can reach this API regardless of its own origin.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory registry of active games: room_id -> RummyGame
games: dict[str, RummyGame] = {}


@app.get("/")
def health_check():
    return {"status": "ok", "service": "rummy-backend"}


# ---------------- Auth ----------------

@app.post("/register", response_model=schemas.TokenResponse)
def register(payload: schemas.RegisterRequest, db: Session = Depends(get_db)):
    existing = db.query(models.User).filter(models.User.username == payload.username).first()
    if existing:
        raise HTTPException(status_code=400, detail="Username already taken")
    user = models.User(username=payload.username, hashed_password=auth.hash_password(payload.password))
    db.add(user)
    db.commit()
    token = auth.create_access_token(payload.username)
    return schemas.TokenResponse(access_token=token, username=payload.username)


@app.post("/login", response_model=schemas.TokenResponse)
def login(payload: schemas.LoginRequest, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.username == payload.username).first()
    if not user or not auth.verify_password(payload.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="Invalid username or password")
    token = auth.create_access_token(payload.username)
    return schemas.TokenResponse(access_token=token, username=payload.username)


# ---------------- Rooms ----------------

@app.post("/rooms/{room_id}/join")
def peek_room(room_id: str):
    """Lets a client check room status before opening the WebSocket (optional convenience)."""
    game = games.get(room_id)
    return {
        "room_id": room_id,
        "exists": game is not None,
        "players": manager.usernames_in_room(room_id),
        "status": game.status if game else "waiting",
    }


# ---------------- WebSocket gameplay ----------------

@app.websocket("/ws/room/{room_id}")
async def room_socket(websocket: WebSocket, room_id: str):
    await websocket.accept()

    # Step 1: require auth as the first message before doing anything else.
    try:
        raw = await websocket.receive_text()
        data = json.loads(raw)
    except Exception:
        await websocket.close(code=4000)
        return

    if data.get("type") != "auth":
        await websocket.close(code=4001)
        return

    username = auth.decode_access_token(data.get("token", ""))
    if not username:
        await websocket.send_text(json.dumps({"type": "error", "message": "Invalid or expired token"}))
        await websocket.close(code=4001)
        return

    await manager.connect(room_id, username, websocket)
    await manager.broadcast(room_id, {"type": "player_joined", "username": username,
                                       "players": manager.usernames_in_room(room_id)})

    try:
        while True:
            raw = await websocket.receive_text()
            try:
                event = json.loads(raw)
            except json.JSONDecodeError:
                await websocket.send_text(json.dumps({"type": "error", "message": "Malformed message"}))
                continue

            await handle_event(room_id, username, event, db_for_chat=None)

    except WebSocketDisconnect:
        manager.disconnect(room_id, username)
        await manager.broadcast(room_id, {"type": "player_left", "username": username,
                                           "players": manager.usernames_in_room(room_id)})


async def handle_event(room_id: str, username: str, event: dict, db_for_chat):
    event_type = event.get("type")
    lock = manager.get_lock(room_id)

    # --- Chat doesn't touch game state, no lock needed ---
    if event_type == "chat":
        text = str(event.get("text", ""))[:500]
        await manager.broadcast(room_id, {"type": "chat", "username": username, "text": text})
        return

    # --- Everything below mutates shared game state: serialize with the room lock ---
    async with lock:
        game = games.get(room_id)

        if event_type == "start":
            players = manager.usernames_in_room(room_id)
            try:
                game = RummyGame(room_id, players)
                game.start()
                games[room_id] = game
            except RummyError as e:
                await manager.send_personal(room_id, username, {"type": "error", "message": str(e)})
                return
            await manager.broadcast_personalized_state(room_id, game, event="game_started")
            return

        if game is None:
            await manager.send_personal(room_id, username, {"type": "error", "message": "Game hasn't started yet"})
            return

        try:
            if event_type == "draw_stock":
                game.draw_from_stock(username)
            elif event_type == "draw_discard":
                game.draw_from_discard(username)
            elif event_type == "discard":
                game.discard(username, event.get("card", ""))
            elif event_type == "declare":
                game.declare(username, event.get("groups", []), event.get("finish_card", ""))
            else:
                await manager.send_personal(room_id, username, {"type": "error", "message": f"Unknown event: {event_type}"})
                return
        except RummyError as e:
            await manager.send_personal(room_id, username, {"type": "error", "message": str(e)})
            return

        await manager.broadcast_personalized_state(room_id, game, event=event_type)
