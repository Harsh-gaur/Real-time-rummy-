import asyncio
import json
import websockets

ALICE_TOKEN = "paste-a-real-token-here"  # get via POST /login
BOB_TOKEN = "paste-a-real-token-here"    # get via POST /login
ROOM = "declare-test-room-5"
URL = f"ws://localhost:8000/ws/room/{ROOM}"


async def listen_one(ws, name):
    msg = await ws.recv()
    data = json.loads(msg)
    print(f"[{name}] <- {data.get('type')}: {json.dumps(data)[:200]}")
    return data


async def main():
    async with websockets.connect(URL) as alice_ws, websockets.connect(URL) as bob_ws:
        await alice_ws.send(json.dumps({"type": "auth", "token": ALICE_TOKEN}))
        await bob_ws.send(json.dumps({"type": "auth", "token": BOB_TOKEN}))

        await listen_one(alice_ws, "alice")
        await listen_one(alice_ws, "alice")
        await listen_one(bob_ws, "bob")

        await alice_ws.send(json.dumps({"type": "start"}))
        alice_state = await listen_one(alice_ws, "alice")
        await listen_one(bob_ws, "bob")

        await alice_ws.send(json.dumps({"type": "draw_stock"}))
        alice_state = await listen_one(alice_ws, "alice")
        await listen_one(bob_ws, "bob")

        hand = alice_state["your_hand"]
        print(f"[alice] hand to declare from: {hand}")

        bad_groups = [hand[:3], hand[3:6], hand[6:9], hand[9:12]]
        await alice_ws.send(json.dumps({"type": "declare", "groups": bad_groups, "finish_card": hand[12]}))
        result = await listen_one(alice_ws, "alice")
        assert result["type"] == "error", "expected the random grouping to be rejected"
        print("[alice] invalid declare correctly rejected over the wire")


if __name__ == "__main__":
    asyncio.run(main())
