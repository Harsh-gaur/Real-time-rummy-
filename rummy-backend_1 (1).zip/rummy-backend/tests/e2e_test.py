import asyncio
import json
import websockets

ALICE_TOKEN = "paste-a-real-token-here"  # get via POST /login
BOB_TOKEN = "paste-a-real-token-here"    # get via POST /login
ROOM = "test-room-1"
URL = f"ws://localhost:8000/ws/room/{ROOM}"


async def player(name, token, actions_after_join):
    async with websockets.connect(URL) as ws:
        await ws.send(json.dumps({"type": "auth", "token": token}))
        print(f"[{name}] connected")
        await actions_after_join(ws, name)


async def listen_for(ws, name, seconds):
    try:
        async with asyncio.timeout(seconds):
            while True:
                msg = await ws.recv()
                data = json.loads(msg)
                print(f"[{name}] <- {data.get('type')}: {data}")
    except (asyncio.TimeoutError, TimeoutError):
        pass


async def alice_flow(ws, name):
    await listen_for(ws, name, 1)  # see player_joined events
    await ws.send(json.dumps({"type": "start"}))
    await listen_for(ws, name, 1)  # see game_started state
    await ws.send(json.dumps({"type": "draw_stock"}))
    await listen_for(ws, name, 1)
    await ws.send(json.dumps({"type": "chat", "text": "good luck bob!"}))
    await listen_for(ws, name, 1)


async def bob_flow(ws, name):
    await listen_for(ws, name, 5)  # just observe everything alice triggers


async def main():
    await asyncio.gather(
        player("alice", ALICE_TOKEN, alice_flow),
        player("bob", BOB_TOKEN, bob_flow),
    )


if __name__ == "__main__":
    asyncio.run(main())
