import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from app.game import RummyGame, RummyError


def test_start_deals_correct_hand_sizes():
    game = RummyGame("room1", ["alice", "bob"])
    game.start()
    assert len(game.hands["alice"]) == 13
    assert len(game.hands["bob"]) == 13
    assert game.status == "playing"


def test_turn_order_enforced():
    game = RummyGame("room1", ["alice", "bob"])
    game.start()
    try:
        game.draw_from_stock("bob")  # alice goes first
        assert False, "should have raised"
    except RummyError:
        pass


def test_draw_then_discard_advances_turn():
    game = RummyGame("room1", ["alice", "bob"])
    game.start()
    game.draw_from_stock("alice")
    assert len(game.hands["alice"]) == 14
    card_to_discard = str(game.hands["alice"][0])
    game.discard("alice", card_to_discard)
    assert len(game.hands["alice"]) == 13
    assert game.current_player == "bob"


def test_cannot_discard_before_drawing():
    game = RummyGame("room1", ["alice", "bob"])
    game.start()
    try:
        game.discard("alice", str(game.hands["alice"][0]))
        assert False, "should have raised"
    except RummyError:
        pass


def test_pure_sequence_detection():
    game = RummyGame("room1", ["alice", "bob"])
    game.wildcard_rank = "K"  # fixed, so it never collides with test cards below
    from app.game import Card
    cards = [Card("3", "S"), Card("4", "S"), Card("5", "S")]
    assert game._is_pure_sequence(cards) is True


def test_set_detection():
    game = RummyGame("room1", ["alice", "bob"])
    game.wildcard_rank = "K"  # fixed, so it never collides with test cards below
    from app.game import Card
    cards = [Card("7", "S"), Card("7", "H"), Card("7", "D")]
    assert game._is_set(cards) is True


def test_rejects_invalid_player_count():
    try:
        RummyGame("room1", ["only_one"])
        assert False, "should require 2-6 players"
    except RummyError:
        pass


def test_full_declare_flow_wins_game():
    from app.game import Card
    game = RummyGame("room1", ["alice", "bob"])
    game.start()
    game.wildcard_rank = "K"  # fixed, so it can't accidentally wild-out our hand below

    # Rig alice's hand: 3 pure sequences + 1 set = valid declare
    game.hands["alice"] = [
        Card("A", "S"), Card("2", "S"), Card("3", "S"),        # pure sequence
        Card("5", "H"), Card("6", "H"), Card("7", "H"),        # pure sequence
        Card("9", "C"), Card("9", "D"), Card("9", "H"),        # set
        Card("4", "D"), Card("5", "D"), Card("6", "D"),        # pure sequence
        Card("Q", "C"),                                        # finish card
    ]
    game.phase = "discard"  # must have drawn already to declare

    groups = [
        ["AS", "2S", "3S"],
        ["5H", "6H", "7H"],
        ["9C", "9D", "9H"],
        ["4D", "5D", "6D"],
    ]
    result = game.declare("alice", groups, finish_card="QC")
    assert result is True
    assert game.status == "finished"
    assert game.winner == "alice"


def test_declare_rejects_invalid_groups():
    from app.game import Card
    game = RummyGame("room1", ["alice", "bob"])
    game.start()
    game.wildcard_rank = "K"
    game.hands["alice"] = [
        Card("A", "S"), Card("2", "S"), Card("3", "S"),
        Card("5", "H"), Card("6", "H"), Card("8", "H"),  # NOT a valid sequence (gap, no joker)
        Card("9", "C"), Card("9", "D"), Card("9", "H"),
        Card("4", "D"), Card("5", "D"), Card("6", "D"),
        Card("Q", "C"),
    ]
    game.phase = "discard"
    groups = [
        ["AS", "2S", "3S"],
        ["5H", "6H", "8H"],  # invalid
        ["9C", "9D", "9H"],
        ["4D", "5D", "6D"],
    ]
    try:
        game.declare("alice", groups, finish_card="QC")
        assert False, "should have rejected the invalid group"
    except RummyError:
        pass


def test_declare_rejects_wrong_phase():
    game = RummyGame("room1", ["alice", "bob"])
    game.start()
    game.phase = "draw"  # hasn't drawn yet this turn
    try:
        game.declare("alice", [["AS", "2S", "3S"]], finish_card="4S")
        assert False, "should require draw phase before declaring"
    except RummyError:
        pass


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_")]
    passed = 0
    for t in tests:
        try:
            t()
            print(f"PASS: {t.__name__}")
            passed += 1
        except Exception as e:
            print(f"FAIL: {t.__name__} -> {e}")
    print(f"\n{passed}/{len(tests)} tests passed")
